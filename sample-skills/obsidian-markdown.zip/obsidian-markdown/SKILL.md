---
name: obsidian-markdown
description: 创建和编辑带有维基链接、嵌入、提示、属性和其他Obsidian特定语法的Obsidian风格Markdown。当在Obsidian中处理.md文件或用户提及维基链接、提示、元数据、标签、嵌入或Obsidian笔记时使用。
---

# Skill Content
This is the content of the skill.
